import { Component, OnInit } from '@angular/core';
import { Patient } from 'src/model/patient.model';
import { ApiService } from '../app/services/api-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'fhir-app-test';
  public patientData= [];
 
  constructor(
    private apiService: ApiService
  ) { }

  ngOnInit() {
    this.apiService.getPatients().subscribe(
      (data:any) => {
        if(data) {
          if(data.entry && data.entry.length > 0){           
            data.entry.map((res)=>{
                              if(res.resource.gender) {
                  let name = '';
                  let nameDetails = (res.resource.name && res.resource.name.length > 0) ? res.resource.name[0]: '' ;
                    if(nameDetails !==  '') {
                      let firstName = (nameDetails.family) ? nameDetails.family: '' ;
                      let lastName = (nameDetails.given && nameDetails.given.length > 0) ? nameDetails.given[0]: '';
                      let prefix = (nameDetails.prefix && nameDetails.prefix.length > 0) ? nameDetails.prefix[0]: '';
                      name = prefix + '' + firstName + ' ' + lastName;
                    } 
                    this.patientData.push({id:res.resource.id,gender:res.resource.gender,birthDate:res.resource.birthDate,name:name}) 
                }
            });
            console.log('patientData', this.patientData);

          }
        }
      }
    )
  }
}


