export class Patient {
    id: string;
    birthDate: string;
    gender: string;
    name: string;
    resourceType: string;
  }